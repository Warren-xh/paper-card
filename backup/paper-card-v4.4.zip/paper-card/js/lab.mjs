// Practice logs (实操记录): a lighter companion to paper cards for coding and
// training sessions. One log per session, kept in data/logs/<id>.json.
import { validDate, todayISO, normalizeTags, validId, makeId, safeUrl, stripMd, sortBy } from "./model.mjs";
import { normalizeLinks } from "./ghlinks.mjs";

export const LOG_DIR = "data/logs/";
export const LOGS_INDEX_PATH = "data/logs-index.json";

export const STATUS_LABELS = { doing: "进行中", done: "完成" };

// Quick entries recorded while working, each stamped with the time.
export const STEPS = Object.freeze([
  { type: "▶", label: "操作" },
  { type: "✗", label: "报错" },
  { type: "✓", label: "成功" },
  { type: "?", label: "疑问" },
  { type: "✎", label: "笔记" },
]);
const STEP_TYPES = new Set(STEPS.map((s) => s.type));
export const stepLabel = (type) => STEPS.find((s) => s.type === type)?.label || "";

// The parts written once the session is over.
export const PARTS = Object.freeze([
  { key: "conclusion", title: "结论" },
  { key: "fixes", title: "问题与解决" },
  { key: "code", title: "关键代码 / 命令" },
  { key: "results", title: "结果" },
  { key: "next", title: "下次要做" },
]);

const str = (value, max = Infinity) => (typeof value === "string" ? value.slice(0, max) : "");

/* ---------- uploaded code files: code/<log id>/<relative path> ---------- */
export const CODE_DIR = "code/";
export const FILE_MAX_BYTES = 25 * 1024 * 1024;
export const UPLOAD_MAX_BYTES = 100 * 1024 * 1024;
export const UPLOAD_MAX_FILES = 200;
const BAD_CHARS = /[\x00-\x1f\\:*?"<>|]/g;
const HAS_BAD_CHAR = /[\x00-\x1f\\:*?"<>|]/;

// Cleans one relative path from an upload; "" when nothing usable is left.
export function cleanRelPath(rel) {
  return String(rel || "")
    .split("/")
    .map((part) => part.replace(BAD_CHARS, "_").trim())
    .filter((part) => part && part !== "." && part !== "..")
    .join("/")
    .slice(0, 240);
}

export function validFilePath(path) {
  if (typeof path !== "string" || path.length > 300 || !path.startsWith(CODE_DIR)) return false;
  const parts = path.slice(CODE_DIR.length).split("/");
  return parts.length >= 2 && validId(parts[0]) && parts.every((p) => p && p !== "." && p !== ".." && !HAS_BAD_CHAR.test(p));
}

// Folders and files that should never be uploaded from a project:
// dependencies, caches, and anything that looks like a secret.
const SKIP_DIRS = new Set(["node_modules", ".git", "__pycache__", ".venv", "venv", ".idea", ".vscode", ".ipynb_checkpoints", ".mypy_cache", ".pytest_cache", "wandb"]);
const SECRET_FILE = /^(\.env(\..*)?|.*\.(pem|key|p12|pfx)|id_(rsa|dsa|ecdsa|ed25519)(\.pub)?|\.npmrc|\.pypirc|credentials(\.json)?)$/i;
export function skipReason(rel) {
  const parts = String(rel).split("/");
  const name = parts.at(-1);
  if (parts.slice(0, -1).some((p) => SKIP_DIRS.has(p))) return "依赖或缓存";
  if (name === ".DS_Store" || name === "Thumbs.db") return "系统文件";
  if (SECRET_FILE.test(name)) return "可能含密钥";
  return "";
}

// Files shown as text in the browser; everything else is download-only.
const TEXT_EXT = /\.(py|ipynb|js|mjs|cjs|ts|tsx|jsx|json|jsonl|md|txt|rst|sh|bash|zsh|ps1|bat|ya?ml|toml|cfg|ini|conf|c|cc|cpp|h|hpp|cu|cuh|java|kt|scala|go|rs|rb|php|r|m|jl|sql|html|css|scss|vue|svelte|csv|tsv|tex|bib|lua|swift|dart|proto|xml|gradle|log)$/i;
const TEXT_NAME = /^(dockerfile|makefile|cmakelists\.txt|requirements.*\.txt|readme|license|\.gitignore)$/i;
export const isTextFile = (name) => TEXT_EXT.test(name) || TEXT_NAME.test(name.split("/").pop());

// Notebook cells as plain text, so .ipynb previews stay readable.
export function notebookText(json) {
  const nb = typeof json === "string" ? JSON.parse(json) : json;
  return (nb.cells || [])
    .map((c) => {
      const src = Array.isArray(c.source) ? c.source.join("") : String(c.source || "");
      return c.cell_type === "markdown" ? "# ── markdown ──\n" + src.replace(/^/gm, "# ") : src;
    })
    .join("\n\n");
}

export function formatSize(bytes) {
  if (!(bytes >= 0)) return "";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(1) + " MB";
}
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

export function nowTime(now = new Date()) {
  return String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
}

export function newLogId(date, title, random = Math.random) {
  return makeId(date, title, random, "log");
}

export function emptyLog(id = "") {
  return {
    version: 1,
    id,
    title: "",
    date: "",
    status: "doing",
    hours: null,
    project: "",
    tags: [],
    env: "",
    link: "",
    goal: "",
    steps: [],
    conclusion: "",
    fixes: "",
    code: "",
    results: "",
    next: "",
    papers: [],
    files: [],
    github: [],
    notes: "",
    createdAt: "",
    updatedAt: "",
  };
}

export function normalizeLog(raw) {
  if (!raw || typeof raw !== "object") throw new Error("记录格式不正确。");
  if (!validId(raw.id)) throw new Error("记录编号不正确。");
  const l = emptyLog(raw.id);
  l.title = str(raw.title).trim();
  l.date = validDate(raw.date) ? raw.date : "";
  l.status = raw.status === "done" ? "done" : "doing";
  const hours = typeof raw.hours === "number" ? raw.hours : parseFloat(raw.hours);
  l.hours = Number.isFinite(hours) && hours >= 0 && hours <= 200 ? Math.round(hours * 10) / 10 : null;
  l.project = str(raw.project).trim();
  l.tags = normalizeTags(raw.tags);
  l.env = str(raw.env).trim();
  l.link = safeUrl(str(raw.link).trim());
  l.goal = str(raw.goal).trim();
  l.steps = (Array.isArray(raw.steps) ? raw.steps : [])
    .map((s) => ({
      type: STEP_TYPES.has(s?.type) ? s.type : "✎",
      time: TIME_RE.test(s?.time) ? s.time : "",
      text: str(s?.text).trim(),
      solve: !!s?.solve,
      answer: str(s?.answer).trim(),
    }))
    .filter((s) => s.text)
    .slice(0, 5000);
  l.conclusion = str(raw.conclusion).trim();
  for (const k of ["fixes", "code", "results", "next"]) l[k] = str(raw[k], 50000);
  l.papers = [...new Set((Array.isArray(raw.papers) ? raw.papers : []).filter(validId))].slice(0, 30);
  const seen = new Set();
  l.files = (Array.isArray(raw.files) ? raw.files : [])
    .filter((f) => f && validFilePath(f.path) && !seen.has(f.path) && seen.add(f.path))
    .map((f) => ({ path: f.path, size: Number.isFinite(f.size) && f.size >= 0 ? Math.round(f.size) : null }))
    .slice(0, 500);
  l.github = normalizeLinks(raw.github);
  l.notes = str(raw.notes);
  l.createdAt = str(raw.createdAt, 40);
  l.updatedAt = str(raw.updatedAt, 40);
  return l;
}

// Steps flagged 待解决 that have no fix written yet.
export const openSteps = (l) => l.steps.filter((s) => s.solve && !s.answer);

export function plainText(l) {
  return [
    l.title, l.project, l.tags.join(" "), l.env, l.goal,
    l.steps.map((s) => s.text + " " + s.answer).join(" "),
    l.files.map((f) => f.path.split("/").pop()).join(" "),
    l.github.map((u) => u.replace("https://github.com/", "")).join(" "),
    l.conclusion, stripMd(l.fixes), stripMd(l.code), stripMd(l.results), stripMd(l.next), stripMd(l.notes),
  ]
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

export function summarize(l) {
  return {
    id: l.id,
    title: l.title,
    date: l.date,
    status: l.status,
    hours: l.hours,
    project: l.project,
    tags: l.tags,
    conclusion: l.conclusion,
    steps: l.steps.length,
    errors: l.steps.filter((s) => s.type === "✗").length,
    open: openSteps(l).length,
    papers: l.papers,
    files: l.files.length,
    text: plainText(l).slice(0, 20000),
    updatedAt: l.updatedAt,
  };
}

export function emptyIndex() {
  return { version: 1, updatedAt: "", logs: [] };
}

const byNewest = (a, b) =>
  (b.date || "").localeCompare(a.date || "") || (b.updatedAt || "").localeCompare(a.updatedAt || "") || (a.id < b.id ? 1 : -1);

export function normalizeIndex(raw) {
  if (!raw || raw.version !== 1 || !Array.isArray(raw.logs)) return emptyIndex();
  return {
    version: 1,
    updatedAt: str(raw.updatedAt, 40),
    logs: raw.logs
      .filter((x) => x && validId(x.id))
      .map((x) => ({ ...x, tags: Array.isArray(x.tags) ? x.tags : [], papers: Array.isArray(x.papers) ? x.papers : [] }))
      .sort(byNewest),
  };
}

export function upsertIndex(index, log, now = new Date().toISOString()) {
  const logs = index.logs.filter((x) => x.id !== log.id);
  logs.push(summarize(log));
  logs.sort(byNewest);
  return { version: 1, updatedAt: now, logs };
}

export function removeFromIndex(index, id, now = new Date().toISOString()) {
  return { version: 1, updatedAt: now, logs: index.logs.filter((x) => x.id !== id) };
}

// Logs that mention a paper card (shown on that card's page).
export const logsForPaper = (logs, cardId) => logs.filter((x) => x.papers.includes(cardId));

export function search(logs, { query = "", tag = "", project = "", status = "" } = {}) {
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
  return logs.filter((x) => {
    if (tag && !x.tags.some((t) => t.toLowerCase() === tag.toLowerCase())) return false;
    if (project && x.project !== project) return false;
    if (status === "open" ? !x.open : status && x.status !== status) return false;
    if (!terms.length) return true;
    const hay = (x.date + " " + x.title + " " + x.conclusion + " " + x.text).toLowerCase();
    return terms.every((t) => hay.includes(t));
  });
}

export const LOG_SORTS = Object.freeze([
  ["date", "日期：新→旧"], ["date-asc", "日期：旧→新"], ["updated", "最近修改"], ["hours", "用时最长"], ["open", "待解决最多"], ["title", "标题 A→Z"],
]);

export function sortLogs(list, key = "date") {
  const date = (x) => x.date;
  const updated = (x) => x.updatedAt;
  switch (key) {
    case "date-asc": return sortBy(list, [[date, "asc"], [updated, "asc"]]);
    case "updated": return sortBy(list, [[updated, "desc"]]);
    case "hours": return sortBy(list, [[(x) => x.hours, "desc"], [date, "desc"]]);
    case "open": return sortBy(list, [[(x) => x.open || 0, "desc"], [date, "desc"]]);
    case "title": return sortBy(list, [[(x) => x.title, "asc"]]);
    default: return sortBy(list, [[date, "desc"], [updated, "desc"]]);
  }
}

export function stats(logs, today = todayISO()) {
  const sum = (list) => Math.round(list.reduce((t, x) => t + (Number(x.hours) || 0), 0) * 10) / 10;
  const month = today.slice(0, 7);
  return {
    total: logs.length,
    doing: logs.filter((x) => x.status !== "done").length,
    thisMonth: logs.filter((x) => (x.date || "").startsWith(month)).length,
    hours: sum(logs),
    open: logs.reduce((t, x) => t + (x.open || 0), 0),
  };
}

export function tagCounts(logs) {
  const counts = new Map();
  for (const x of logs) for (const t of x.tags) counts.set(t, (counts.get(t) || 0) + 1);
  return [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
}

export function projectList(logs) {
  const counts = new Map();
  for (const x of logs) if (x.project) counts.set(x.project, (counts.get(x.project) || 0) + 1);
  return [...counts].sort((a, b) => b[1] - a[1]);
}

export function logToMarkdown(l, paperTitles = new Map()) {
  const out = ["# " + (l.date ? l.date + " · " : "") + (l.title || "（未写标题）")];
  const meta = ["状态：" + STATUS_LABELS[l.status]];
  if (l.hours != null) meta.push("用时：" + l.hours + " 小时");
  if (l.project) meta.push("项目：" + l.project);
  if (l.env) meta.push("环境：" + l.env);
  if (l.link) meta.push("代码：" + l.link);
  if (l.tags.length) meta.push("标签：" + l.tags.map((t) => "#" + t).join(" "));
  out.push(meta.join(" ｜ "));
  if (l.goal) out.push("**目标**：" + l.goal);
  if (l.conclusion) out.push("> **结论**：" + l.conclusion);
  if (l.steps.length)
    out.push("## 过程\n" + l.steps.map((s) => "- " + (s.time ? s.time + " " : "") + s.type + " " + s.text + (s.solve ? "\n  → " + (s.answer || "（待解决）") : "")).join("\n"));
  const sec = (title, body) => body && body.trim() && out.push("## " + title + "\n" + body.trim());
  sec("问题与解决", l.fixes);
  sec("关键代码 / 命令", l.code);
  sec("结果", l.results);
  sec("下次要做", l.next);
  if (l.github.length) out.push("## GitHub 提交\n" + l.github.map((u) => "- " + u).join("\n"));
  if (l.files.length) out.push("## 代码文件\n" + l.files.map((f) => "- " + f.path + (f.size != null ? "（" + formatSize(f.size) + "）" : "")).join("\n"));
  if (l.papers.length) out.push("## 相关论文\n" + l.papers.map((id) => "- " + (paperTitles.get(id) || id)).join("\n"));
  sec("笔记", l.notes);
  return out.join("\n\n") + "\n";
}

export function newLog(date = todayISO()) {
  return { ...emptyLog("00000000-new-0000"), date };
}
